# CHAT TRANSFER — copy/paste this whole block into a new chat to resume

You are resuming an NMS Base Builder governance-package work-stream in **Builder mode**: prove-don't-attest, executable validation over self-attestation, one clarifying question at a time, end every substantive reply with the PROTOCOL banner.

## Who / what
- User: James. Builds No Man's Sky bases via the "No Man's Sky Base Builder" Blender add-on (v6.4.1; Blender 5.0.1). Work-stream: auditing/cleaning/consolidating the `NMS_master_docs` governance package.
- Current package: **5.07.00** (gate PASS). Extract the uploaded package; deliverables to `/mnt/user-data/outputs`.

## What happened (most recent first)
- **5.07.00 (Wave 2 physical execution):** Absorbed 30 duplicate-law rule docs into **13 survivors**, content-preserving; rule layer **92 -> 62** unique rules. Repointed all refs; the gate caught and forced fixes for 6 real downstream breaks (`.json` sidecars, the placement-intelligence infra REQUIRED list, run_gate fixtures, the canonical covered build, both build packets, the partmap index). Demoted `rules/PART_FAMILY_RULES.json` to informative findings; mirrored 7 effect/use families into the creative index; cross-linked 9 placement families to the validated mechanics that supersede them. Rewrote `OPEN_TOPICS_LOG.md` with **Priority + Success Criteria** fields. Seeded `data/RUNTIME_BEHAVIORS.json` and shipped `reports/WAVE3_EXECUTION_PREP.md`.
- **5.06.x:** Built the classification spine (kind + runtime_status per rule; gate #24), continuity artifacts (this file + structured OPEN_TOPICS_LOG; gate #25), wired the resolver into START HERE + kickoff.

## Why
Eyeball-era duplicates, mis-scoped rules invisible to the resolver, and a write-only creative KB. The full rule-by-rule review is complete and encoded as data; Wave 2 physically executed the consolidations the review approved.

## What was decided
- Operating test: *removing it changes what's allowed/required -> RULE; removing it only changes what you know -> FINDING.*
- Consolidate content-preserving (append as `absorbed from X`, never drop); gate every step.
- Family findings inform via the creative index; placement families are not law.

## What to do next — Wave 3 (read `reports/WAVE3_EXECUTION_PREP.md` + `OPEN_TOPICS_LOG.md`)
1. Author `data/RUNTIME_BEHAVIORS.json` for every KEEP RULE/RECIPE/NEGATIVE.
2. Resolver Fix 2 (filter packet to kind∈{RULE,RECIPE,NEGATIVE} + runtime_status==KEEP + directly applicable).
3. Resolver Fix 1 (emit `applicable_rule_behaviors` not rule-name lists) + update `validation/build_sheet_check.py`; regenerate all packets/fixtures; restore `build_application`.
4. Onboarding gauntlet (artifacts+gate+failure-handling+verdict, not "read").

## Critical mechanics
- Gate to PASS: `python3 release/release_check.py` (gates #24 classification, #25 open-topics structure, version-callout, dangling-ref, RPAM coverage, run_gate self-tests, build-sheet/resolver consistency, partmap drift). Clear `__pycache__`/`.pyc`; set manifest `file_count` to actual; write `protocol_banner_good.txt` with a SEPARATE read-then-write.
- **After any rule rename/merge:** regenerate every packet (`runs/*__PACKET.json`, `validation/gate_fixtures/build_sheet_good.json`) via `part_context_resolver.py --ids … --intent … --out …` and RESTORE `build_application` per part from the prior packet (recover from the last shipped zip if overwritten).
- PRESERVE VERBATIM: `COORD_MODE="XnZY"` / `AXIS_MODE="RIGHT_AT_UP"` / `BASE_ROTATION_MODE="POST_RX90"` / `POST_BASELINE_CORRECTION="LOCAL_Y_180"`; `Position=[x,z,-y]`.

## Standing output requirement (every build/doc update or on "checkpoint")
Provide BOTH: this CHAT TRANSFER doc refreshed, and an updated `OPEN_TOPICS_LOG.md` in the per-topic structure (Issue / Discovery / Why It Matters / Decision / Next Steps / Status / Priority / Success Criteria / Last Updated). Gate #25 enforces it.
